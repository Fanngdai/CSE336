/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lectures;

import java.lang.reflect.Field;

/**
 *
 * @author nick-
 */
public class Card implements java.io.Serializable{
    public Card() {
        
    }
    
    private int cardNumber;
    private String ageRange;
    
    private String firstName;
    private char middleInitial;
    private String lastName;
    private String streetAddress;
    private String city;
    private int zipCode;
    private String suffix;
    private String state;
    private boolean homeDiff;
    
    private String noticePref;
    private String email;
    private String phoneNumber;
    private String cellNumber;
    private boolean signedUp;
    
    private String birthDate;
    private boolean mailCard;    
    
   public int getCardNumber() {
       return cardNumber;
   }
   
   public void setCardNumber(int newCardNumber) {
       cardNumber = newCardNumber;
   }
   
   public String getAgeRange() {
       return ageRange;
   }
   
   public void setAgeRange(String newAgeRange) {
       ageRange = newAgeRange;
   }
   
   public String getFirstName() {
       return firstName;
   }
   
   public void setFirstName(String newFirstName) {
       firstName = newFirstName;
   }
   
   public String getBirthDate() {
       return birthDate;
   }
   
   public void setBirthDate(String newBirthDate) {
       birthDate = newBirthDate;
   }
   
   public String getCellNumber() {
       return cellNumber;
   }
   
   public void setCellNumber(String newCellNumber) {
       cellNumber = newCellNumber;
   }
   
   public String getCity() {
       return city;
   }
   
   public void setCity(String newCity) {
       city = newCity;
   }
   
   public String getEmail() {
       return email;
   }
   
   public void setEmail(String newEmail) {
       email = newEmail;
   }
   
   public boolean getHomeDiff() {
       return homeDiff;
   }
   
   public void setHomeDiff(boolean newHomeDiff) {
       homeDiff = newHomeDiff;
   }
   
   public String getLastName() {
       return lastName;
   }
   
   public void setLastName(String newLastName) {
       lastName = newLastName;
   }
   
   public boolean getMailCard() {
        return mailCard;
   }
   
   public void setMailCard(boolean newMailCard) {
       mailCard = newMailCard;
   }
   
   public char getMiddleInitial() {
       return middleInitial;
   }
   
   public void setMiddleInitial(char newMiddleInitial) {
       middleInitial = newMiddleInitial;
   }
   
   public String getNoticePref() {
       return noticePref;
   }
   
   public void setNoticePref(String newNoticePref) {
       noticePref = newNoticePref;
   }
   
   public String getPhoneNumber() {
       return phoneNumber;
   }
   
   public void setPhoneNumber(String newPhoneNumber) {
       phoneNumber = newPhoneNumber;
   }
   
   public boolean getSignedUp() {
       return signedUp;
   }
   
   public void setSignedUp(boolean newSignedUp) {
       signedUp = newSignedUp;
   }
   
   public String getState() {
       return state;
   }
   
   public void setState(String newState) {
       state = newState;
   }
   
   public String getStreetAddress() {
       return streetAddress;
   }
   
   public void setStreetAddress(String newStreetAddress) {
       streetAddress = newStreetAddress;
   }
   
   public String getSuffix() {
       return suffix;
   }
   
   public void setSuffix(String newSuffix) {
       suffix = newSuffix;
   }
   
   public int getZipCode() {
       return zipCode;
   }
   
   public void setZipCode(int newZipCode) {
       zipCode = newZipCode;
   }
}
