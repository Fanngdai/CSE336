/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lectures;

import java.io.*;

/**
 *
 * @author nick-
 */
public class SerializeCards {

    public SerializeCards() {
        
    }
    
    public void serializeCards() {
        Card[] cardList = new Card[5];
        Card c1 = new Card();
        Card c2 = new Card();
        Card c3 = new Card();
        Card c4 = new Card();
        Card c5 = new Card();

        c1.setAgeRange("Adult (Ages 17 and over)");
        c2.setAgeRange("Adult (Ages 17 and over)");
        c3.setAgeRange("Seniors (Ages 62 and over)");
        c4.setAgeRange("Young Adults (Age 13-16)");
        c5.setAgeRange("Young Adults (Age 13-16)");

        c1.setBirthDate("01/06/1992");
        c2.setBirthDate("03/24/1989");
        c3.setBirthDate("09/09/1964");
        c4.setBirthDate("12/02/2005");
        c5.setBirthDate("12/15/2003");

        c1.setCardNumber(123);
        c2.setCardNumber(222);
        c3.setCardNumber(595);
        c4.setCardNumber(440);
        c5.setCardNumber(789);

        c1.setCellNumber("123456789");

        c1.setCity("Little Neck");
        c2.setCity("Stony Brook");
        c3.setCity("Stony Brook");
        c4.setCity("Washington D.C.");
        c5.setCity("Albany");

        c2.setEmail( "nicholaschen@gmail.com");
        c3.setEmail( "fannydai@gmail.com");
        c4.setEmail( "sophia@hotmail.com");
        c5.setEmail( "arpita@yahoo.com");

        c1.setNoticePref("Phone Call");
        c2.setNoticePref("Email (default)");
        c3.setNoticePref("Email (default)");
        c4.setNoticePref("Email (default)");
        c5.setNoticePref("Email (default)");

        c1.setFirstName("Bob");
        c2.setFirstName("Nicholas");
        c3.setFirstName("Fanny");
        c4.setFirstName("Sophia");
        c5.setFirstName("Arpita");

        c1.setHomeDiff(true);
        c2.setHomeDiff(false);
        c3.setHomeDiff(true);
        c4.setHomeDiff(false);
        c5.setHomeDiff(false);

        c1.setLastName("Smith");
        c2.setLastName("Chen");
        c3.setLastName("Dai");
        c4.setLastName("Song");
        c5.setLastName("Abrol");

        c1.setMailCard(true);
        c2.setMailCard(true);
        c3.setMailCard(false);
        c4.setMailCard(true);
        c5.setMailCard(false);

        c1.setMiddleInitial('G');
        c2.setMiddleInitial('S');
        c3.setMiddleInitial('D');
        c4.setMiddleInitial('C');
        c5.setMiddleInitial('F');

        c1.setPhoneNumber("987654321");

        c1.setSignedUp(false);
        c2.setSignedUp(true);
        c3.setSignedUp(false);
        c4.setSignedUp(false);
        c5.setSignedUp(false);

        c1.setState("NY");
        c2.setState("NY");
        c3.setState("NY");
        c4.setState("NY");
        c5.setState("NY");

        c1.setStreetAddress("4130 247. St.");
        c2.setStreetAddress("200 Circle Rd.");
        c3.setStreetAddress("220 Circle Rd.");
        c4.setStreetAddress("15590 Square Avenue");
        c5.setStreetAddress("Homeless");

        c3.setSuffix("Sr.");

        c1.setZipCode(12345);
        c2.setZipCode(44422);
        c3.setZipCode(99999);
        c4.setZipCode(98765);
        c5.setZipCode(11790);

        cardList[0] = c1;
        cardList[1] = c2;
        cardList[2] = c3;
        cardList[3] = c4;
        cardList[4] = c5;

        try {
            for (int i = 1; i < 6; i++) {
                String fileName = "Card" + i;
                FileOutputStream fileOut = new FileOutputStream(fileName + ".ser");
                ObjectOutputStream out = new ObjectOutputStream(fileOut);
                out.writeObject(cardList[i - 1]);
                out.close();
                fileOut.close();
            }
        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    public Card[] deSerializeCards() {
        Card[] cardList2 = new Card[5];
        try {
            for (int i = 1; i < 6; i++) {
                String cardName = "Card" + i + ".ser";
                FileInputStream fileIn = new FileInputStream("Card" + i + ".ser");
                ObjectInputStream in = new ObjectInputStream(fileIn);
                cardList2[i - 1] = (Card) in.readObject();
                in.close();
                fileIn.close();
            }
        } catch (IOException i) {
            i.printStackTrace();

        } catch (ClassNotFoundException c) {
            c.printStackTrace();

        }
        return cardList2;
    }
}
